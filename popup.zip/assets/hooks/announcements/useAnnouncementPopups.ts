import { useEffect, useState } from 'react'
import { AnnouncementPopup, dismiss, getVisibleAnnouncementPopups } from '../../core/announcement'

interface UseAnnouncementPopupsReturn {
  current: AnnouncementPopup | null
  dismissCurrent: () => void
}

export function useAnnouncementPopups(): UseAnnouncementPopupsReturn {
  const [queue, setQueue] = useState<AnnouncementPopup[]>([])

  useEffect(() => {
    getVisibleAnnouncementPopups()
      .then(setQueue)
      .catch(() => setQueue([]))
  }, [])

  const current = queue[0] ?? null

  const dismissCurrent = () => {
    if (!current) return
    dismiss(current.id)
    setQueue((prev) => prev.slice(1))
  }

  return { current, dismissCurrent }
}
