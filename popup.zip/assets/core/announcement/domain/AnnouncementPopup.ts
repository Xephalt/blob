export interface AnnouncementPopup {
  id: string
  title: string
  content: string // HTML depuis CKEditor
  imageUrl: string | null
  priority: number
}
