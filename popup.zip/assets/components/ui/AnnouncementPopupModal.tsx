import React from 'react'
import BasicModal from './BasicModal'
import { AnnouncementPopup } from '../../core/announcement'

interface Props {
  popup: AnnouncementPopup
  onClose: () => void
  current: number
  total: number
}

export function AnnouncementPopupModal({ popup, onClose, current, total }: Props) {
  return (
    <BasicModal open onClose={onClose}>
      <div className="announcement-popup">

        <div className="announcement-popup__header">
          <h2 className="announcement-popup__title">{popup.title}</h2>
          {total > 1 && (
            <span className="announcement-popup__counter">
              {current}/{total}
            </span>
          )}
        </div>

        <div className={`announcement-popup__body ${popup.imageUrl ? 'announcement-popup__body--with-image' : ''}`}>
          {popup.imageUrl && (
            <img
              src={popup.imageUrl}
              alt=""
              className="announcement-popup__image"
            />
          )}
          {/* HTML depuis CKEditor — dangerouslySetInnerHTML intentionnel */}
          <div
            className="announcement-popup__content"
            dangerouslySetInnerHTML={{ __html: popup.content }}
          />
        </div>

        <div className="announcement-popup__footer">
          <button onClick={onClose} className="btn btn--primary">
            {current < total ? `Suivant (${current}/${total})` : 'Terminer'}
          </button>
        </div>

      </div>
    </BasicModal>
  )
}
