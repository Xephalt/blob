import React from 'react'
import { useAnnouncementPopups } from '../../hooks/announcements/useAnnouncementPopups'
import { AnnouncementPopupModal } from './AnnouncementPopupModal'

interface Props {
  children: React.ReactNode
}

/**
 * À placer dans App.tsx autour des routes.
 *
 * <AnnouncementPopupProvider>
 *   <Routes />
 * </AnnouncementPopupProvider>
 */
export function AnnouncementPopupProvider({ children }: Props) {
  const { current, dismissCurrent, queue } = useAnnouncementPopups()

  return (
    <>
      {children}
      {current && (
        <AnnouncementPopupModal
          popup={current}
          onClose={dismissCurrent}
          current={queue.indexOf(current) + 1}
          total={queue.length}
        />
      )}
    </>
  )
}
