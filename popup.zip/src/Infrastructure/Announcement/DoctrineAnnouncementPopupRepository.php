<?php

namespace App\Infrastructure\Announcement;

use App\Domain\Announcement\AnnouncementPopup;
use App\Domain\Announcement\AnnouncementPopupRepositoryInterface;
use Doctrine\DBAL\Connection;
use Symfony\Component\Uid\Uuid;

final class DoctrineAnnouncementPopupRepository implements AnnouncementPopupRepositoryInterface
{
    public function __construct(
        private readonly Connection $connection,
    ) {
    }

    public function save(AnnouncementPopup $popup): void
    {
        $exists = $this->connection->fetchOne(
            'SELECT id FROM announcement_popup WHERE id = ?',
            [$popup->getId()]
        );

        if ($exists) {
            $this->connection->update('announcement_popup', [
                'title'      => $popup->getTitle(),
                'content'    => $popup->getContent(),
                'image_url'  => $popup->getImageUrl(),
                'is_active'  => (int) $popup->isActive(),
                'priority'   => $popup->getPriority(),
            ], ['id' => $popup->getId()]);

            return;
        }

        $this->connection->insert('announcement_popup', [
            'id'         => $popup->getId(),
            'title'      => $popup->getTitle(),
            'content'    => $popup->getContent(),
            'image_url'  => $popup->getImageUrl(),
            'is_active'  => (int) $popup->isActive(),
            'priority'   => $popup->getPriority(),
            'created_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
        ]);
    }

    public function findById(string $id): ?AnnouncementPopup
    {
        $row = $this->connection->fetchAssociative(
            'SELECT * FROM announcement_popup WHERE id = ?',
            [$id]
        );

        if (!$row) {
            return null;
        }

        return $this->hydrate($row);
    }

    public function findActiveOrderedByPriority(): array
    {
        $rows = $this->connection->fetchAllAssociative(
            'SELECT * FROM announcement_popup WHERE is_active = 1 ORDER BY priority ASC'
        );

        return array_map($this->hydrate(...), $rows);
    }

    public function findAllOrderedByPriority(): array
    {
        $rows = $this->connection->fetchAllAssociative(
            'SELECT * FROM announcement_popup ORDER BY priority ASC'
        );

        return array_map($this->hydrate(...), $rows);
    }

    public function delete(string $id): void
    {
        $this->connection->delete('announcement_popup', ['id' => $id]);
    }

    private function hydrate(array $row): AnnouncementPopup
    {
        return AnnouncementPopup::reconstitute(
            id: $row['id'],
            title: $row['title'],
            content: $row['content'],
            imageUrl: $row['image_url'],
            isActive: (bool) $row['is_active'],
            priority: (int) $row['priority'],
        );
    }
}
