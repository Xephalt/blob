<?php

namespace App\Domain\Announcement;

final class AnnouncementPopup
{
    private function __construct(
        private readonly string $id,
        private string $title,
        private string $content,
        private ?string $imageUrl,
        private bool $isActive,
        private int $priority,
    ) {
    }

    public static function create(
        string $id,
        string $title,
        string $content,
        ?string $imageUrl,
        int $priority,
    ): self {
        if (trim($title) === '') {
            throw new \InvalidArgumentException('Title cannot be empty');
        }

        if (trim($content) === '') {
            throw new \InvalidArgumentException('Content cannot be empty');
        }

        if ($priority < 0) {
            throw new \InvalidArgumentException('Priority must be a positive integer');
        }

        return new self(
            id: $id,
            title: $title,
            content: $content,
            imageUrl: $imageUrl,
            isActive: false,
            priority: $priority,
        );
    }

    public static function reconstitute(
        string $id,
        string $title,
        string $content,
        ?string $imageUrl,
        bool $isActive,
        int $priority,
    ): self {
        return new self(
            id: $id,
            title: $title,
            content: $content,
            imageUrl: $imageUrl,
            isActive: $isActive,
            priority: $priority,
        );
    }

    public function activate(): void
    {
        $this->isActive = true;
    }

    public function deactivate(): void
    {
        $this->isActive = false;
    }

    public function update(
        string $title,
        string $content,
        ?string $imageUrl,
        int $priority,
    ): void {
        if (trim($title) === '') {
            throw new \InvalidArgumentException('Title cannot be empty');
        }

        if (trim($content) === '') {
            throw new \InvalidArgumentException('Content cannot be empty');
        }

        if ($priority < 0) {
            throw new \InvalidArgumentException('Priority must be a positive integer');
        }

        $this->title = $title;
        $this->content = $content;
        $this->imageUrl = $imageUrl;
        $this->priority = $priority;
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function getContent(): string
    {
        return $this->content;
    }

    public function getImageUrl(): ?string
    {
        return $this->imageUrl;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }

    public function getPriority(): int
    {
        return $this->priority;
    }
}
