<?php

namespace Tests\App\Domain\Announcement;

use App\Domain\Announcement\AnnouncementPopup;
use PHPUnit\Framework\TestCase;

final class AnnouncementPopupTest extends TestCase
{
    public function test_create_popup_with_valid_data(): void
    {
        $popup = AnnouncementPopup::create(
            id: 'uuid-1',
            title: 'Nouvelle feature',
            content: '<p>Découvrez la nouvelle feature</p>',
            imageUrl: null,
            priority: 0,
        );

        $this->assertSame('Nouvelle feature', $popup->getTitle());
        $this->assertFalse($popup->isActive());
        $this->assertSame(0, $popup->getPriority());
    }

    public function test_popup_is_inactive_by_default(): void
    {
        $popup = AnnouncementPopup::create(
            id: 'uuid-1',
            title: 'Titre',
            content: 'Contenu',
            imageUrl: null,
            priority: 0,
        );

        $this->assertFalse($popup->isActive());
    }

    public function test_activate_popup(): void
    {
        $popup = AnnouncementPopup::create('uuid-1', 'Titre', 'Contenu', null, 0);
        $popup->activate();

        $this->assertTrue($popup->isActive());
    }

    public function test_deactivate_popup(): void
    {
        $popup = AnnouncementPopup::create('uuid-1', 'Titre', 'Contenu', null, 0);
        $popup->activate();
        $popup->deactivate();

        $this->assertFalse($popup->isActive());
    }

    public function test_create_throws_on_empty_title(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        AnnouncementPopup::create('uuid-1', '   ', 'Contenu', null, 0);
    }

    public function test_create_throws_on_empty_content(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        AnnouncementPopup::create('uuid-1', 'Titre', '', null, 0);
    }

    public function test_create_throws_on_negative_priority(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        AnnouncementPopup::create('uuid-1', 'Titre', 'Contenu', null, -1);
    }

    public function test_update_popup(): void
    {
        $popup = AnnouncementPopup::create('uuid-1', 'Titre', 'Contenu', null, 0);
        $popup->update('Nouveau titre', '<p>Nouveau contenu</p>', 'https://img.png', 2);

        $this->assertSame('Nouveau titre', $popup->getTitle());
        $this->assertSame(2, $popup->getPriority());
        $this->assertSame('https://img.png', $popup->getImageUrl());
    }
}
